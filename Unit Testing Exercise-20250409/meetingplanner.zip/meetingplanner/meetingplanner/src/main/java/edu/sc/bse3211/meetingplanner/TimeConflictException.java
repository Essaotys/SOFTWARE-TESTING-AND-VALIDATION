package edu.sc.bse3211.meetingplanner;

public class TimeConflictException extends Exception {

	private static final long serialVersionUID = 8147822812157714367L;

	public TimeConflictException() {
		// TODO Auto-generated constructor stub
	}

	public TimeConflictException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TimeConflictException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public TimeConflictException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TimeConflictException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}
}
